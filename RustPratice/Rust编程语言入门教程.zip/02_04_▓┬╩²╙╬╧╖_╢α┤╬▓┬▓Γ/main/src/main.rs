/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.14
描  述: 比较数字和神秘数字
备  注:  
修改记录: 

  1.  日期: 2024.12.14
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

use rand::Rng;
use std::io;
use std::cmp::Ordering;

fn main() {
    let rng_num = rand::thread_rng().gen_range(1, 101);         //随机数字

    println!("猜数游戏!!!");
    
    loop {
        let mut guess_num = String::new();                              //猜测数字值
        println!("请输入一个数字:");

        io::stdin().read_line(&mut guess_num).expect("Failed to read line");
        
        println!("您猜测的数字是: {}", guess_num);
    
        let guess_num: u32 =  match guess_num.trim().parse() {
            Ok(num) => num,
            Err(_) => continue,
        };

        match guess_num.cmp(&rng_num){
            Ordering::Less => println!("Too small!"),
            Ordering::Greater => println!("Too big!"),
            Ordering::Equal => {
                println!("You win!");
                break;
            },
        }
    }
}
