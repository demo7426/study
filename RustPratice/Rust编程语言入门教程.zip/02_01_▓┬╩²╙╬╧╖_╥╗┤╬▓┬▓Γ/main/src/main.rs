/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.14
描  述: 猜测一个输入的数字
备  注:  
修改记录: 

  1.  日期: 2024.12.14
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

use std::io;

fn main() {
    println!("猜数!");
    println!("猜测一个数");
    
    let mut guess = String::new();

    io::stdin().read_line(&mut guess).expect("无法读取行");

    println!("你猜测的数是: {}", guess);
}
