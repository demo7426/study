/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.16
描  述: 控制流 循环(loop while for)
备  注: 
修改记录: 

  1.  日期: 2024.12.16
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

fn main() {
    let mut counter = 0;

    //loop 循环语句
    let num =  loop {
        counter += 1;

        if counter >= 100 {
            break counter * 2
        }
    };

    println!("loop 循环语句:");
    println!("{}", counter);
    println!("{}\n", num);

    //while 循环语句
    while counter > 0 {
        counter -= 1;
    }

    println!("while 循环语句:");
    println!("{}\n", counter);

    //for 循环语句
    let arr: [i32; 5] = [1, 2, 3, 4, 5];

    println!("for 循环语句:");
    for element in arr {
        println!("{}", element);
    }
}
