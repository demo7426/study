/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.16
描  述: 控制流 if else
备  注: 
修改记录: 

  1.  日期: 2024.12.16
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

fn main() {
    
    let mut numbers = 20;

    if numbers % 2 == 0 {
        println!("{} is an even number.", numbers);
    } else {
        println!("{} is an odd number.", numbers);
    }

    numbers = if numbers % 2 == 0 { 1 } else { 0 };
    
    println!("{}", numbers);
}
