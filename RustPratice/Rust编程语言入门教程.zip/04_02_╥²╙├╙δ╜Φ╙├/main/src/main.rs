/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.17
描  述: 引用和借用
备  注: 
        1、引用：允许你引用某些值而不取得其所有权;
        2、当引用作为函数参数时，为借用;
        3、可修改的引用只能同时存在一个，不可修改的引用可以同时存在多个（可修改的引用和不可修改的引用不可以同时存在）;
修改记录: 

  1.  日期: 2024.12.17
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

fn main() {
    let mut s = String::from("Hello");

    let s1 = test_01(&mut s);
    println!("{}\n", s1);

    test02();
}

fn test_01(s3: &mut String) -> &String {
    s3 .push_str(" world");
    s3
}

fn test02(){
    let mut s = String::from("Hello");

    {
        let r1 = &s;  
        println!("r1: {}", r1);
    }

    let r2 = &mut s;  
    println!("r2: {}", r2);
}


