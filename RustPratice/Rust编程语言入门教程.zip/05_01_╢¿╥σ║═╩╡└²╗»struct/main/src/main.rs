/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.18
描  述: 结构体
备  注: 
修改记录: 

  1.  日期: 2024.12.18
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/
#[derive(Debug)]
struct User {
    name: String,
    age: u32,
    address: String,
    email: String,
}

struct Color (i16, i16, i16);
struct Point (i16, i16, i16);

fn main() {
    let user = User{
        name: "Alice".to_string(),
        age: 28,
        address: "123 Main St".to_string(),
        email: "alice@example.com".to_string(),
    };

    let user02 = User{
        name: "Bob".to_string(),
        ..user
    };

    // println!("{:#?}", user);
    println!("{:#?}", user02);

    //tuple struct
    let black = Color(0, 0, 0);
    let origin = Point(0, 0, 0);
    
    println!("{}", black.0);
    println!("{}", origin.0);
}
