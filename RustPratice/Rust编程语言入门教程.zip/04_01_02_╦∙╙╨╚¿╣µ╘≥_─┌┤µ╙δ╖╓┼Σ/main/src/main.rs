/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.17
描  述: 所有权规则、内存与分配
备  注: 拥有Drop trait的数据类型所有权会转移，比如String数据类型，它的真实数据存储在Heap内
修改记录: 

  1.  日期: 2024.12.17
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

fn main() {
    test_01();
    test_02();
    test_03();
}

//可变变量测试函数
fn test_01() {
    let mut s = String::from("Hello");
    
    s.push_str(", world");

    println!("{}\n", s);
}

//所有权转移
fn test_02() {
    let s = String::from("test_02");

    let s1 = &s;

    println!("{}\n", s1);
}

fn test_03() {
    let s = String::from("test_03");

    let s1 = s.clone();         //数据克隆，s会新拷贝出一份原始数据，并将其所有权交给s1

    println!("{}", s);
    println!("{}\n", s1);
}

