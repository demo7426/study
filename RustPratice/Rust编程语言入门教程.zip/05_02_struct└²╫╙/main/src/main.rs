/*************************************************
Copyright (C), 2009-2012    , Level Chip Co., Ltd.
文件名:	main.rs
作  者:	钱锐      版本: V0.1.0     新建日期: 2024.12.18
描  述: 结构体例子
备  注: 
修改记录: 

  1.  日期: 2024.12.18
      作者: 钱锐
      内容:
          1) 此为模板第一个版本;
      版本:V0.1.0

*************************************************/

struct Rectangle{
    width: u32,
    height: u32,
}

fn main() {
    let rect = Rectangle{
        width: 30,
        height: 50,
    };

    println!("{}", area(&rect));
}

fn area(rec: &Rectangle) -> u32 {
    rec.width * rec.height
}

